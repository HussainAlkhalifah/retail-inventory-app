package com.example.pc.inventoryapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.pc.inventoryapp.Data.RetailContract;
import com.example.pc.inventoryapp.Data.RetailDbHelper;

public class MainActivity extends AppCompatActivity {
    private RetailDbHelper retailDbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        retailDbHelper = new RetailDbHelper(this);
        insertProductData();
        displayDatabaseInfo();
    }

    public void insertProductData() {
        // Gets the database in write mode
        SQLiteDatabase db = retailDbHelper.getWritableDatabase();
        ContentValues vals = new ContentValues();
        vals.put(RetailContract.RetailEntry.COLUMN_PRODUCT_NAME, "KITKAT");
        vals.put(RetailContract.RetailEntry.COLUMN_PRODUCT_PRICE, 0.5);
        vals.put(RetailContract.RetailEntry.COLUMN_PRODUCT_QUANTITY,20);
        vals.put(RetailContract.RetailEntry.COLUMN_PRODUCT_SUPPLIER_NAME, "Nestile");
        vals.put(RetailContract.RetailEntry.COLUMN_PRODUCT_SUPPLIER_PHONE, "+41219241111");
        long newRowId = db.insert(RetailContract.RetailEntry.TABLE_NAME, null, vals);
    }

    private void displayDatabaseInfo() {
        SQLiteDatabase db = retailDbHelper.getReadableDatabase();
        String[] project = {RetailContract.RetailEntry._ID, RetailContract.RetailEntry.COLUMN_PRODUCT_NAME,
                RetailContract.RetailEntry.COLUMN_PRODUCT_PRICE, RetailContract.RetailEntry.COLUMN_PRODUCT_QUANTITY,
                RetailContract.RetailEntry.COLUMN_PRODUCT_SUPPLIER_NAME,
                RetailContract.RetailEntry.COLUMN_PRODUCT_SUPPLIER_PHONE};
        Cursor cursor = db.query(
                RetailContract.RetailEntry.TABLE_NAME,project, null, null, null, null, null);
        TextView displayView = (TextView) findViewById(R.id.display_view);
        try {
            displayView.setText("The products table contains " + cursor.getCount() + " products.\n\n");
            displayView.append(RetailContract.RetailEntry._ID + " - " +
                    RetailContract.RetailEntry.COLUMN_PRODUCT_NAME + " - " +
                    RetailContract.RetailEntry.COLUMN_PRODUCT_PRICE + " - " +
                    RetailContract.RetailEntry.COLUMN_PRODUCT_QUANTITY + " - " +
                    RetailContract.RetailEntry.COLUMN_PRODUCT_SUPPLIER_NAME + " - " +
                    RetailContract.RetailEntry.COLUMN_PRODUCT_SUPPLIER_PHONE + "\n");
            int idColumnIndex = cursor.getColumnIndex(RetailContract.RetailEntry._ID);
            int nameColumnIndex = cursor.getColumnIndex(RetailContract.RetailEntry.COLUMN_PRODUCT_NAME);
            int priceColumnIndex = cursor.getColumnIndex(RetailContract.RetailEntry.COLUMN_PRODUCT_PRICE);
            int quaColumnIndex = cursor.getColumnIndex(RetailContract.RetailEntry.COLUMN_PRODUCT_QUANTITY);
            int supNameColumnIndex = cursor.getColumnIndex(RetailContract.RetailEntry.COLUMN_PRODUCT_SUPPLIER_NAME);
            int supPhoneColumnIndex = cursor.getColumnIndex(RetailContract.RetailEntry.COLUMN_PRODUCT_SUPPLIER_PHONE);
            while (cursor.moveToNext()) {
                int currentID = cursor.getInt(idColumnIndex);
                String curName = cursor.getString(nameColumnIndex);
                int curPrice = cursor.getInt(priceColumnIndex);
                int curQuantity = cursor.getInt(quaColumnIndex);
                String curSupName = cursor.getString(supNameColumnIndex);
                String curSupPhone = cursor.getString(supPhoneColumnIndex);

                // Display the values from each column of the current row in the cursor in the TextView
                displayView.append(("\n" + currentID + " - " + curName + " - " + curPrice + " - " +
                        curQuantity + " - " + curSupName + " - " + curSupPhone));
            }
        } finally {
            cursor.close();
        }
    }
}
